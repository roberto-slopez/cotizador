$(function(){

	//Valores select
	var $VALOR_SELECT_CURSO = $('#select_curso');
	var $VALOR_SELECT_PAIS = $('#select_pais');

	function onLoad(){
		$('#list_valores').hide();
		$('#boton_imprimir').hide();
	}

		$VALOR_SELECT_CURSO.on('change', function(event) {

			if($VALOR_SELECT_CURSO.val() === '1'){
				$VALOR_SELECT_PAIS.attr('disabled', false);
				$('#list_valores').slideToggle('slow');
				$('#boton_imprimir').slideToggle('slow');
			}else{
				$VALOR_SELECT_PAIS.attr('disabled', true);

			}
		});

	onLoad();
});